﻿namespace FotoFly
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class PhotoMetadataEnums
    {
        public enum Orientations : int
        {
            Unknown,
            Landscape,
            Portrait
        }
    }
}
